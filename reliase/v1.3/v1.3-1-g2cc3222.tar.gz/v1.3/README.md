the version translator intended for users Linux. Before as use translator in file translator.py replace user_name on own user_name in the user folder. And then already just run it for execution.
Base:
System - Ubuntu20.04lts
Programming environment - Python3.8.2
Programming environment - Python3.9.5
Python dependencies from requirements.txt
Install:
Command for install Python:
sudo apt install python3.8
sudo apt install python3.9
Command for install pip:
sudo apt install python3-pip
Check version Python:
Python3 --version
Check version pip:
pip3 --version
Others.
Base:
Install:
pip3 install certifi
pip3 install chardet
pip3 install google-trans
pip3 install googletrans==3.1.0a0
pip3 install h11
pip3 install h2
pip3 install hpack
pip3 install hstspreload
pip3 install httpcore
pip3 install httpx
pip3 install hyperframe
pip3 install idna
pip3 install rfc3986
pip3 install sniffio
Upgrade:
pip3 install --upgrade chardet
pip3 install --upgrade hyperframe
pip3 install --upgrade rfc
Check install python-libs:
command python3.8
command python3.9
import certifi
import chardet
import google_trans
import googletrans
import h11
import h2
import hpack
import hstspreload
import httpcore
import httpx
import hyperframe
import idna
import rfc3986
import sniffio
Reliase:
version==1.0
version==1.1
version==1.2
version==1.3
